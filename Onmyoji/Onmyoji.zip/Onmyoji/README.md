# Onmyoji说明

网易游戏《阴阳师》刷觉醒用脚本。

只作为学习使用。

> python版本: 3.6.4

使用：

> ![点击下载Onmyoji]()，解压，进入Onmyoji文件夹 

> pip install -r requirement.txt
> 或者：pip3 install -r requirement.txt

> python gui_surface.py
> 或者: python3 gui_surface.py
